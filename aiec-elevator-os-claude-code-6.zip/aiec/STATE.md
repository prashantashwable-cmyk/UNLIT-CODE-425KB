# STATE (update after every task; this is the memory between cloud sessions)

**Current phase:** 0 (Decide) — build not started
**Last updated:** (fill)

NEXT: blocked - Phase 0 needs owner answers to tier 1 decisions (see Blocked); then write docs/adr/0001-stack.md

## Done
- Package verified in a scratch container: Postgres 16 + PostGIS install works via apt; `scripts/test-db.sh schema` applies `docs/appendix/schema-skeleton.sql` (plus `scripts/db-shim.sql` stand-ins for Supabase `authenticated` role and `auth.uid()`) with zero errors. Not yet verified inside an actual Claude Code cloud environment.

## Known findings (Phase 1 must fix)
- `bash scripts/test-db.sh rls` shows 15 app tables WITHOUT row level security: approval, audit_event, consent_record, evidence_check, ledger_journal, lift, payment, project_assignment, provider_webhook, quote_version, role_assignment, rule_config, site, stage_transition, user_account. Draft only enables RLS on 5 tables and defines 1 policy.
- Draft has ~20 tables; spec §29.1 lists ~25 more not yet written (customer, supplier, bom, container, permit, licence, inspection, task, ...).
- `apply_stage_transition` exists only as a comment, not a function.

## In progress
-

## Blocked (needs owner / professional / provider / device)
- Tier 1 decisions: DEC-012, 014, 005, 016, 017, 027, 031 (see docs/spec/40-decisions-overview.md)
- Written opinions: lawyer, CA, licensed lift engineer, payment provider

## NEEDS_DEVICE / NEEDS_PROVIDER backlog
-

## Assumptions made (each must cite a DEC default)
-
